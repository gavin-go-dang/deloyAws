from django.apps import AppConfig


class EstoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Estore'
